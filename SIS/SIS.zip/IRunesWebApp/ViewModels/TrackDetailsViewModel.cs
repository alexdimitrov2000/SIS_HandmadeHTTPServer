﻿namespace IRunesWebApp.ViewModels
{
    public class TrackDetailsViewModel
    {
        public string AlbumId { get; set; }

        public string TrackId { get; set; }
    }
}
