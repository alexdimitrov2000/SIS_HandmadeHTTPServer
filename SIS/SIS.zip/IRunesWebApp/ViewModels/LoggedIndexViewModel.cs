﻿namespace IRunesWebApp.ViewModels
{
    public class LoggedIndexViewModel
    {
        public string Username { get; set; }
    }
}
