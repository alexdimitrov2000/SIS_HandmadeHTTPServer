﻿namespace IRunesWebApp.ViewModels
{
    public class AlbumDetailsViewModel
    {
        public string Id { get; set; }
    }
}
