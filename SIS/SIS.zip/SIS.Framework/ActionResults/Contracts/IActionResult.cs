﻿namespace SIS.Framework.ActionResults.Contracts
{
    public interface IActionResult
    {
        string Invoke();
    }
}
