﻿namespace SIS.Framework.ActionResults.Contracts
{
    public interface IError : IActionResult
    {
    }
}
